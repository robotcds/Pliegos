# Registro documental de requisitos de perfiles y equipo – CP00152/2024 (ASEPEYO)

## 1. Equipo mínimo, puestos, número de personas y estructura exigida

### Lote 1: Administración de servidores y aplicaciones informáticas
- El equipo de trabajo debe contar con el dimensionamiento adecuado para cubrir los servicios contratados en todas las fases del contrato [PPT CP001522024 F.pdf, pág. 19].
- Perfiles profesionales mínimos a incluir en la propuesta técnica para todos los lotes: Responsable de la transición, Responsable de la prestación del servicio, Responsable de sistemas, Responsable del Centro de Atención al Usuario [PPT CP001522024 F.pdf, pág. 19].
- Para los roles más relevantes (excepto Responsable de la Transición), el adjudicatario debe comprometer la estabilidad de las personas asignadas durante toda la duración del contrato. El Responsable de la Transición solo es necesario durante la fase de transición [PPT CP001522024 F.pdf, pág. 20].
- En caso de cambios en las personas asignadas a estos roles, se debe acordar previamente con Asepeyo [PPT CP001522024 F.pdf, pág. 20].
- El equipo de trabajo actual (dotación orientativa, no mínimo exigido) para cada área de conocimiento se detalla en ANEXO A.pdf, págs. 7-17. Ejemplo (L1.S1 Mainframe): zVM, zVSE, CICS (4 técnicos), DLI, Vsam Tune (3), IBM COBOL, Pacbase (2), Gss, Epic, DrD (2), Panvalet batch y online (2), Software provisto por Asepeyo (2). Para el resto de servicios, ver tablas completas en ANEXO A.pdf, págs. 9, 14-15, 17.
- Deberán establecerse guardias 24x7x365 para cada área de conocimiento/tecnología [ANEXO A.pdf, pág. 7, 15].

### Lote 2: Operación del servicio asociada al puesto de trabajo
- El equipo de trabajo debe contar con el dimensionamiento adecuado para cubrir los servicios contratados en todas las fases del contrato [PPT CP001522024 F.pdf, pág. 19].
- Perfiles profesionales mínimos a incluir en la propuesta técnica: Responsable de la transición, Responsable de la prestación del servicio, Responsable de sistemas, Responsable del Centro de Atención al Usuario [PPT CP001522024 F.pdf, pág. 19].
- El equipo de trabajo actual (dotación orientativa, no mínimo exigido) para cada área de conocimiento se detalla en ANEXO A.pdf, págs. 47-50, 57, 59-60. Ejemplo (L2.S1 Virtualización): Técnico de Sistemas CITRIX (3), Técnico de sistemas Citrix Workspace y entornos VDI Xenapp (3). Para el resto de servicios, ver tablas completas en ANEXO A.pdf, págs. 50, 57, 59-60.
- El CAU está dividido en 2 niveles: 1 responsable del centro de atención a usuarios (RSU), 1 coordinador de operaciones (COSU), 5 técnicos de soporte usuarios (TSU, nivel 2), 11 operadores de soporte a usuarios (OSU, nivel 1), 2 personas de backup para contingencias. El número máximo de recursos disponibles en el CAU puede ascender hasta un máximo de 20 personas [ANEXO A.pdf, pág. 57].
- Para los roles más relevantes (excepto Responsable de la Transición), el adjudicatario debe comprometer la estabilidad de las personas asignadas durante toda la duración del contrato. El Responsable de la Transición solo es necesario durante la fase de transición [PPT CP001522024 F.pdf, pág. 20].
- En caso de cambios en las personas asignadas a estos roles, se debe acordar previamente con Asepeyo [PPT CP001522024 F.pdf, pág. 20].

### Lote 3: Suministro y soporte de licencias
- NO CONSTA EN LA DOCUMENTACION REVISADA ningún requisito de equipo mínimo, puestos, número de personas ni estructura exigida para el Lote 3.

## 2. Titulaciones, colegiación, certificaciones, habilitaciones y equivalencias admitidas
- Para el Lote 3, los partners oficiales de Camunda deben contar con profesionales certificados para asegurar el éxito en la implementación de la plataforma (únicamente para el lote 3) [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].
- Certificación platino de la empresa mantenedora en UDS Virtual Cable (aplicable únicamente al Lote 2), y los documentos de capacitación de sus operarios [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].
- Acreditación del cumplimiento de las normas de garantía de la calidad y de gestión medioambiental: ISO 20000 e ISO 27001 para los servicios L1.S1, L1.S2 y L2.S1 [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de colegiación profesional.

## 3. Años y tipo de experiencia exigida, sector, tecnología, funciones y periodos de referencia
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de años mínimos de experiencia individual por perfil para la ejecución del contrato.
- Para la solvencia técnica de la empresa (no de personas), se exige relación de proyectos de migración tecnológica, despliegue de arquitecturas híbridas y virtualización, pero esto es requisito de empresa, no de personas [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].
- Para el Lote 2, criterio puntuable: número de proyectos de implantación de plataformas de virtualización (UDS Virtual Cable) en los últimos 3 años para empresas de más de 500 empleados [CP001522024 ANEXOS.doc, Anexo XI, pág. 22].

## 4. Dedicaciones, jornadas, disponibilidad, guardias, presencialidad, ubicación, idiomas y sustituciones
- Todos los trabajadores implicados en el contrato deberán trabajar dentro de la Unión Europea [PPT CP001522024 F.pdf, pág. 20].
- Para los roles más relevantes (excepto Responsable de la Transición), el adjudicatario debe comprometer la estabilidad de las personas asignadas durante toda la duración del contrato. El Responsable de la Transición solo es necesario durante la fase de transición [PPT CP001522024 F.pdf, pág. 20].
- Guardias 24x7x365 para cada área de conocimiento/tecnología en Lote 1 y Lote 2 [ANEXO A.pdf, págs. 7, 15].
- El adjudicatario podrá tener flexibilidad con el volumen de trabajadores asignados para poder dar servicio tanto en los momentos de mayor trabajo como en los de menor necesidad [PPT CP001522024 F.pdf, pág. 20].
- Preferiblemente, los trabajadores responsables de desempeñar los roles clave tendrán disponibilidad para viajar a Barcelona cuando las reuniones periódicas así lo requieran [PPT CP001522024 F.pdf, pág. 20].
- Todas las comunicaciones en el contrato deberán ser como mínimo en castellano o catalán. En cualquier servicio donde se deba interactuar con los usuarios de Asepeyo, tanto por voz como por escrito, se deberá usar el castellano o catalán [PPT CP001522024 F.pdf, pág. 9].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de presencialidad obligatoria, salvo la preferencia de disponibilidad para viajar a Barcelona para reuniones.
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de jornada mínima, FTE, ni turnos concretos.

## 5. Compromisos de adscripción, permanencia, reemplazo y documentación acreditativa exigida
- Compromiso a dedicar o adscribir a la ejecución del contrato los medios personales o materiales suficientes para ello (art. 76.2 LCSP) [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].
- El adjudicatario se compromete a mantener el nivel de conocimientos y cualificación del equipo de trabajo durante el periodo de ejecución del expediente mediante la formación continua en las tecnologías que forman parte del catálogo de servicios objeto de la prestación a Asepeyo [PPT CP001522024 F.pdf, pág. 20].
- En caso de cambios en las personas asignadas a los roles clave, se debe acordar previamente con Asepeyo [PPT CP001522024 F.pdf, pág. 20].
- El adjudicatario debe presentar declaración responsable de adscripción de medios personales y materiales en la fase de adjudicación (Anexo IV.2) [CP001522024 ANEXOS.doc, Anexo IV.2].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de presentación de CVs nominativos en la oferta.

## 6. Criterios de adjudicación vinculados a perfiles (criterios puntuables)
- Lote 2: Criterio puntuable PF 2.1: Número de proyectos de implantación de plataformas de virtualización (UDS Virtual Cable) en los últimos 3 años para empresas de más de 500 empleados. 4 puntos: 7 o más proyectos; 3 puntos: 6 proyectos; 2 puntos: 5 proyectos; 1 punto: 4 proyectos; 0 puntos: no acredita experiencia o documentación insuficiente [CP001522024 ANEXOS.doc, Anexo XI, pág. 22].
- NO CONSTA EN LA DOCUMENTACION REVISADA ningún otro criterio de adjudicación que puntúe perfiles individuales, titulaciones, experiencia personal, idiomas, etc.

## 7. Separación de requisitos de experiencia de empresa/proyectos previos
- La experiencia en migración tecnológica, despliegue de arquitecturas híbridas y virtualización exigida en la solvencia técnica es requisito de empresa, no de personas [CP001522024 ANEXOS.doc, Anexo IV, pág. 8].

## 8. Horas, periodos, cobertura, acreditación, incorporación, sustitución y continuidad
- Las tablas de unidades de recurso y líneas base de horas, instancias, nodos, usuarios, etc., por servicio y periodo, se encuentran en ANEXO V.xls, hojas Lote 1 y Lote 2. Ejemplo: L1.S1 Mainframe: 670 MIPS, 480 instancias VSAM, 75 instancias DL1, 4200 horas bolsa de reducción de mainframe, periodo anual/mensual según tabla [ANEXO V.xls, hoja Lote 1].
- L1.S2 Administración de servidores: 303 instancias VM Linux productivo, 700 instancias VM Windows productivo, 210 instancias VM Linux no productivo, 220 instancias VM Windows no productivo, periodo anual/mensual según tabla [ANEXO V.xls, hoja Lote 1].
- L1.S3 Administración de BBDD y Middleware: 30 instancias WAS productivo, 30 instancias DB2 Advanced Edition productivo, 405 instancias Lotus Domino productivo, 20 instancias MSFT SQL productivo, 30 instancias PostgreSQL productivo, 6 instancias MongoDB productivo, 15 instancias MySQL standard productivo, 4 instancias MySQL enterprise productivo, 20 CPUs productivo, 15 instancias Maria DB productivo, 50 instancias DB2 Express Edition productivo, 3 instancias MSFT SQL Express productivo, 12 nodos Elasticsearch productivo, 50 instancias Windows VDI (VDA) productivo, y equivalentes para entornos no productivos [ANEXO V.xls, hoja Lote 1].
- L1.S4 Administración y operación de aplicaciones: 1 coste fijo anual [ANEXO V.xls, hoja Lote 1].
- L1.S0 Horas de servicios profesionales: 6000 horas bolsa [ANEXO V.xls, hoja Lote 1].
- L1.S01 Proceso y gestión de la transición: 1 coste fijo único [ANEXO V.xls, hoja Lote 1].
- L2.S1 Administración de plataforma de virtualización: 1 coste fijo anual [ANEXO V.xls, hoja Lote 2].
- L2.S2 Puesto de trabajo: 180 nodos (dependencias físicas), 4150 usuarios, 35 líneas activas Fax-Cloud, 2400 páginas enviadas Fax-Cloud, 1 servicio VPN [ANEXO V.xls, hoja Lote 2].
- L2.S3 Centro de atención al usuario: 3800 usuarios [ANEXO V.xls, hoja Lote 2].
- L2.S4 Administración y Gestión Suite Google Workspace y Notes: 1 coste fijo anual [ANEXO V.xls, hoja Lote 2].
- L2.S5 Almacenamiento físico: 1 coste fijo anual [ANEXO V.xls, hoja Lote 2].
- L2.S6 Proyectos de innovación y desarrollo: 3000 horas de soporte [ANEXO V.xls, hoja Lote 2].
- L2.S0 Proceso y gestión de la transición: 1 coste fijo único [ANEXO V.xls, hoja Lote 2].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de cobertura de ausencias, vacaciones, bajas o refuerzos/picos con número mínimo de suplentes o turnos.
- El adjudicatario podrá tener flexibilidad con el volumen de trabajadores asignados para poder dar servicio tanto en los momentos de mayor trabajo como en los de menor necesidad [PPT CP001522024 F.pdf, pág. 20].
- El adjudicatario se compromete a mantener el nivel de conocimientos y cualificación del equipo de trabajo durante el periodo de ejecución del expediente mediante la formación continua en las tecnologías que forman parte del catálogo de servicios objeto de la prestación a Asepeyo [PPT CP001522024 F.pdf, pág. 20].

## 9. Funciones, conocimientos, sustituciones, adscripción de medios
- Las funciones y tareas por perfil y servicio se detallan en los apartados de descripción de servicios y en las tablas de ANEXO A.pdf, págs. 17-46 (ver funciones por aplicación, proceso, sistema, etc.).
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de sustitución automática ni plazo máximo para sustituciones, salvo la obligación de acordar previamente con Asepeyo los cambios en los roles clave [PPT CP001522024 F.pdf, pág. 20].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de adscripción nominativa de personas en la oferta.

## 10. Documentación acreditativa y fases de presentación
- En la fase de presentación de ofertas: Declaración responsable de compromiso de adscripción de medios personales y materiales (Anexo IV.2) [CP001522024 ANEXOS.doc, Anexo IV.2].
- Solo la empresa propuesta como adjudicataria debe aportar la documentación acreditativa de la personalidad y capacidad jurídica, solvencia económica y financiera, técnica y profesional, y titulaciones/certificaciones exigidas (Anexo IV.1) [CP001522024 ANEXOS.doc, Anexo IV.1].
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de presentación de CVs nominativos en la oferta.

## 11. Condiciones especiales de ejecución y obligaciones esenciales
- Condición especial de ejecución: La empresa contratista y subcontratista, caso de que se permita la subcontratación, establecerán medidas que faciliten la conciliación de la vida laboral, personal y familiar del personal adscrito a la ejecución del contrato y podrán consistir en al menos una de las siguientes: flexibilidad de horarios, adecuación de horarios, teletrabajo, apoyo económico para escuelas infantiles/personas dependientes, formación interna en horario laboral, no establecer reuniones en tiempos límites de descanso. La empresa adjudicataria deberá presentar en el plazo de tres meses desde la firma del contrato, declaración responsable en la que indique qué medida o medidas tiene implantada, aplicable al personal adscrito al contrato. Dicha medida/s se deberá mantener durante toda la vigencia del contrato. El incumplimiento de esta condición especial de ejecución dará lugar a la imposición de penalidades [CP001522024 ANEXOS.doc, Anexo VI].
- Obligación contractual esencial: Cumplimiento de la normativa de protección de datos (LOPD, RGPD) [PCAP CP001522024.pdf, pág. 33].

## 12. Penalizaciones y consecuencias de incumplimiento
- Incumplimiento de los acuerdos de nivel de servicio (ANS) y de los hitos críticos de transición (2, 3, 4) = incumplimiento contractual [ANEXO D.pdf, pág. 39].
- Penalizaciones específicas por incumplimiento de ANS y de hitos de transición, ver ANEXO C.pdf, págs. 29-30 y CP001522024 ANEXOS.doc, Anexo VIII.

---

## Discrepancias y pendientes de aclaración
- NO CONSTA EN LA DOCUMENTACION REVISADA discrepancia interna relevante entre documentos respecto a los requisitos de perfiles y equipo, cantidades mínimas, titulaciones, experiencia, dedicación, cobertura, sustituciones, adscripción, acreditación o condiciones especiales de ejecución.
- No se han identificado discrepancias en la documentación revisada.

---

**Fin del registro de requisitos de perfiles y equipo para CP00152/2024 (ASEPEYO).**