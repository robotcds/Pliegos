# Registro documental de requisitos de perfiles y equipo – CP00152/2024 (ASEPEYO)

## 1. Estructura general y fases de presentación/acreditación

- **Solicitud de participación**: No se exige documentación de equipo ni perfiles en la solicitud de participación. [PCAP CP001522024.pdf, pág. 11]
- **Presentación de ofertas**: No se exige la presentación de CV, titulaciones, certificados ni relación nominal de equipo en la oferta inicial. [PCAP CP001522024.pdf, pág. 11-12]
- **Acreditación a requerimiento**: Solo la empresa propuesta como adjudicataria debe aportar documentación acreditativa de la solvencia técnica y profesional, incluidas titulaciones y experiencia del equipo directivo/responsable, y compromisos de adscripción de medios personales. [CP001522024 ANEXOS.doc, Anexo IV.1, IV.2]
- **Adjudicación**: El adjudicatario debe presentar la documentación justificativa de la adscripción de medios personales y materiales comprometidos, así como la documentación de solvencia técnica y profesional, en el plazo de 10 días hábiles desde el requerimiento. [PCAP CP001522024.pdf, pág. 29]
- **Formalización**: No se exige documentación adicional de equipo salvo la declaración responsable de adscripción de medios. [CP001522024 ANEXOS.doc, Anexo IV.2]
- **Ejecución**: El adjudicatario debe mantener durante toda la vigencia del contrato los medios personales comprometidos y comunicar cualquier variación. [CP001522024 ANEXOS.doc, Anexo IV.2]

## 2. Equipo mínimo, puestos, número de personas y estructura exigida

### Lote 1: Administración de servidores y aplicaciones informáticas

- El equipo de trabajo debe estar dimensionado para cubrir todos los servicios contratados en todas las fases del contrato. [PPT CP001522024 F.pdf, pág. 19]
- Perfiles mínimos exigidos (no número de personas, sino roles):
  - Responsable de la transición
  - Responsable de la prestación del servicio
  - Responsable de sistemas
  - Responsable del Centro de Atención al Usuario (CAU)
  - Técnicos de sistemas por área de conocimiento/tecnología (ver detalle en Anexo A)
- El equipo debe garantizar guardias 24x7x365 para cada área de conocimiento/tecnología. [ANEXO A.pdf, pág. 7, 15]
- El número de técnicos por área de conocimiento en el equipo actual (referencia orientativa, no mínimo exigido):
  - Mainframe: 4-2 técnicos por área (zVM, zVSE, CICS, DLI, Vsam Tune, IBM COBOL, Pacbase, Gss, Epic, DrD, Panvalet, software provisto por Asepeyo)
  - Servidores Windows/Linux: 2-4 técnicos por área (VMWARE, Windows, Active Directory, Linux, EMC Networker, Switching, Cloud público, VDI, Bash, Centreon, IBM SmartCloud, Tivoli, Ugold)
  - BBDD y Middleware: 1-3 técnicos por área (DB2, SQL, MySQL/MariaDB, PostgreSQL, MongoDB, Cassandra, Neo4j, ElasticSearch, IBM WAS, Citrix, Rancher, DevOps, Docker, Stack ELK, AWS, Google Cloud, Lotus Domino, Bash, IPcosta, CyberArk, Kaspersky, Sonicwall, WAF, CASB, Zero Trust, $Universe, Centreon, QRADAR)
  - Operación de aplicaciones: 5 jefes de turno, 14 operadores, 3 técnicos de comunicaciones/red, 3 técnicos de infraestructuras, 2 planificadores, 2 backup, 6 expertos de negocio [ANEXO A.pdf, pág. 7-17]

### Lote 2: Operación del servicio asociada al puesto de trabajo

- Perfiles mínimos exigidos (no número de personas, sino roles):
  - Responsable de la transición
  - Responsable de la prestación del servicio
  - Responsable de sistemas
  - Responsable del CAU
  - Técnicos de sistemas por área de conocimiento/tecnología (ver detalle en Anexo A)
- El equipo debe garantizar guardias 24x7x365 para cada área de conocimiento/tecnología. [PPT CP001522024 F.pdf, pág. 20]
- El número de técnicos por área de conocimiento en el equipo actual (referencia orientativa, no mínimo exigido):
  - Administración de servidores Citrix/Virtual Cable: 3 técnicos Citrix, 3 técnicos Citrix Workspace/VDI
  - Puesto de trabajo: 4 técnicos Citrix/ADF, 4 técnicos Windows Server, 4 técnicos Linux, 3 técnicos microinformática, 2 técnicos comunicaciones, 2 técnicos VPN/Citrix ADC, 2 técnicos 2FA, 3 técnicos ciberseguridad
  - CAU: 1 responsable del servicio, 1 coordinador de operaciones, 5 técnicos de soporte usuarios (nivel 2), 11 operadores de soporte a usuarios (nivel 1)
  - Google Workspace y Notes: 2 técnicos Google Workspace, 2 técnicos HCL Lotus Notes, 1 técnico fax, 1 técnico antimalware mail
  - Almacén físico: 2 personal almacén, 2 personal expediciones [ANEXO A.pdf, pág. 47-60]

### Lote 3: Suministro y soporte de licencias

- NO CONSTA EN LA DOCUMENTACION REVISADA ningún requisito de equipo mínimo, perfiles ni estructura de personal para el lote 3. Solo se exige la adscripción de medios personales y materiales suficientes para la ejecución del contrato. [PCAP CP001522024.pdf, pág. 35; CP001522024 ANEXOS.doc, Anexo IV.2]

## 3. Titulaciones, colegiación, certificaciones, habilitaciones y equivalencias admitidas

- No se exige titulación, colegiación ni habilitación específica para los técnicos de los lotes 1 y 2. [CP001522024 ANEXOS.doc, Anexo IV.1, IV.2]
- Para el lote 3, se exige que los partners oficiales de Camunda cuenten con profesionales certificados para asegurar el éxito en la implementación de la plataforma (únicamente para el lote 3). [CP001522024 ANEXOS.doc, Anexo IV.1]
- Para el lote 2, se exige certificación platino de la empresa mantenedora en UDS Virtual Cable y documentos de capacitación de sus operarios. [CP001522024 ANEXOS.doc, Anexo IV.1]
- Para todos los lotes, se exige acreditación del cumplimiento de las normas de garantía de la calidad y de gestión medioambiental: ISO 20000 y, para los servicios L1.S1, L1.S2 y L2.S1, ISO 27001. [CP001522024 ANEXOS.doc, Anexo IV.1]

## 4. Años y tipo de experiencia exigida, sector, tecnología, funciones y periodos de referencia

- No se exige experiencia mínima individual para los técnicos de los lotes 1 y 2. [CP001522024 ANEXOS.doc, Anexo IV.1]
- Para la solvencia técnica de la empresa (no de personas), se exige:
  - Lote 1: Relación de 3 proyectos de migración tecnológica de alta complejidad en los últimos 5 años para clientes con más de 500 empleados.
  - Lote 1: Relación de 3 proyectos de despliegue, gestión y optimización de arquitecturas híbridas on-premise/nube pública en los últimos 5 años para clientes con más de 500 empleados.
  - Lote 2: Relación de 3 proyectos de implantación de plataformas de virtualización (UDS Virtual Cable) en los últimos 3 años para clientes con más de 500 empleados.
- Para el lote 3, los partners oficiales de Camunda deben contar con profesionales certificados. [CP001522024 ANEXOS.doc, Anexo IV.1]
- NO CONSTA EN LA DOCUMENTACION REVISADA experiencia mínima individual exigida por perfil, ni sector ni tecnología concreta para los técnicos de los lotes 1 y 2.

## 5. Dedicaciones, jornadas, disponibilidad, guardias, presencialidad, ubicación, idiomas y sustituciones

- El equipo debe estar dimensionado para cubrir los servicios en todas las fases del contrato, incluyendo picos de trabajo y necesidades variables. [PPT CP001522024 F.pdf, pág. 19-20]
- Guardias 24x7x365 obligatorias para cada área de conocimiento/tecnología en los lotes 1 y 2. [ANEXO A.pdf, pág. 7, 15]
- Todos los trabajadores implicados en el contrato deben trabajar dentro de la Unión Europea. [PPT CP001522024 F.pdf, pág. 20]
- Para los roles más relevantes (excepto Responsable de la Transición), el adjudicatario debe comprometer la estabilidad de las personas asignadas durante toda la duración del contrato. El Responsable de la Transición solo es necesario durante la fase de transición. [PPT CP001522024 F.pdf, pág. 20]
- En caso de cambio de personas asignadas a roles relevantes, debe acordarse previamente con Asepeyo. [PPT CP001522024 F.pdf, pág. 20]
- El adjudicatario debe mantener el nivel de conocimientos y cualificación del equipo mediante formación continua en las tecnologías del catálogo de servicios. [PPT CP001522024 F.pdf, pág. 20]
- Todos los trabajadores deben poder comunicarse en castellano o catalán, tanto por voz como por escrito, en cualquier servicio que implique interacción con usuarios. [PPT CP001522024 F.pdf, pág. 9]
- El CAU debe atender en catalán y castellano, tanto hablado como escrito. [PPT CP001522024 F.pdf, pág. 71]
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de presencialidad, ubicación física concreta, ni jornada mínima o máxima individual por perfil.

## 6. Compromisos de adscripción, permanencia, reemplazo y documentación acreditativa exigida

- El adjudicatario debe comprometerse a adscribir los medios personales y materiales suficientes para la ejecución del contrato, y mantenerlos durante toda la vigencia del contrato. [CP001522024 ANEXOS.doc, Anexo IV.2]
- En caso de sustitución de personas asignadas a roles relevantes (excepto Responsable de la Transición), debe acordarse previamente con Asepeyo. [PPT CP001522024 F.pdf, pág. 20]
- El adjudicatario debe mantener el nivel de conocimientos y cualificación del equipo mediante formación continua. [PPT CP001522024 F.pdf, pág. 20]
- Documentación acreditativa a presentar solo por el adjudicatario propuesto:
  - Copia de titulaciones y currículum o certificaciones exigidas (únicamente para el lote 3 y para la certificación platino UDS Virtual Cable en lote 2). [CP001522024 ANEXOS.doc, Anexo IV.1]
  - Declaración responsable de adscripción de medios personales y materiales (Anexo IV.2). [CP001522024 ANEXOS.doc, Anexo IV.2]
  - Compromiso de mantener los medios durante toda la vigencia del contrato y comunicar cualquier variación. [CP001522024 ANEXOS.doc, Anexo IV.2]

## 7. Criterios de adjudicación vinculados a perfiles (criterios puntuables)

- Lote 2: Criterio PF 2.1 – Número de implantaciones en plataformas de Virtualización de aplicaciones (UDS Virtual Cable) en los últimos 3 años para empresas de más de 500 empleados. Hasta 4 puntos. [ANEXO V.xls, hoja Lote 2]
  - 4 puntos: 7 o más proyectos acreditados
  - 3 puntos: 6 proyectos
  - 2 puntos: 5 proyectos
  - 1 punto: 4 proyectos
  - 0 puntos: No acredita experiencia o documentación insuficiente
- Lote 3: Criterio PF 1.3 – Importe total de Motor de procesos (Camunda). Se exige que los partners oficiales de Camunda cuenten con profesionales certificados. [ANEXO V.xls, hoja Lote 3]
- NO CONSTA EN LA DOCUMENTACION REVISADA ningún otro criterio puntuable vinculado a perfiles individuales, titulaciones, experiencia o equipo mínimo.

## 8. Continuidad, cobertura de ausencias, vacaciones, bajas, refuerzos/picos, formación y condiciones de ejecución

- El adjudicatario debe garantizar la continuidad del servicio y la cobertura de ausencias, vacaciones, bajas y picos de trabajo, dimensionando el equipo según las necesidades del servicio. [PPT CP001522024 F.pdf, pág. 19-20]
- El adjudicatario debe mantener el nivel de conocimientos y cualificación del equipo mediante formación continua en las tecnologías del catálogo de servicios. [PPT CP001522024 F.pdf, pág. 20]
- El adjudicatario debe realizar sesiones formativas de al menos 8 horas cada seis meses sobre nuevas tecnologías implantadas, procesos operativos y herramientas de gestión/control implantadas, preferentemente en formato online, sin coste adicional para Asepeyo. [PPT CP001522024 F.pdf, pág. 23]
- La formación debe ser impartida por instructores cualificados, con acreditación de la formación a los asistentes. [PPT CP001522024 F.pdf, pág. 23]
- El adjudicatario debe presentar anualmente declaración responsable sobre el mantenimiento de las medidas de conciliación laboral implantadas para el personal adscrito al contrato. [CP001522024 ANEXOS.doc, Anexo VI]

## 9. Funciones, conocimientos, sustituciones y adscripción de medios

- Las funciones y conocimientos requeridos por perfil están descritos en los apartados de alcance y requisitos mínimos de cada servicio (ver Anexo A y PPT). [PPT CP001522024 F.pdf, pág. 29-80; ANEXO A.pdf, pág. 7-60]
- En caso de sustitución de personas asignadas a roles relevantes (excepto Responsable de la Transición), debe acordarse previamente con Asepeyo. [PPT CP001522024 F.pdf, pág. 20]
- El adjudicatario debe mantener el nivel de conocimientos y cualificación del equipo mediante formación continua. [PPT CP001522024 F.pdf, pág. 20]

## 10. Horas, periodos, bolsas y cuantificación de recursos

- El modelo económico establece las siguientes unidades de recurso y líneas base iniciales (referencia de dimensionamiento, no mínimo exigido):
  - Lote 1: Mainframe (MIPS: 670, VSAM: 480, DL1: 75, Bolsa de horas: 4200), Servidores virtuales (Windows/Linux: 303/700 productivo, 210/220 no productivo), BBDD y Middleware (instancias: WAS 30/11, DB2 Advanced 30/40, Lotus Domino 405/150, MSFT SQL 20/4, PostgreSQL 30/0, MongoDB 6/6, MySQL 15/7, MySQL enterprise 4/2, MariaDB 15/0, DB2 Express 50/13, MSFT SQL Express 3/0, Elasticsearch 12/12, Windows VDI 50/18), Bolsa de horas de servicios profesionales: 6000. [ANEXO V.xls, hoja Lote 1]
  - Lote 2: Virtualización (coste fijo anual), Puesto de trabajo (180 dependencias físicas, 4150 usuarios), CAU (3800 usuarios), Google Workspace/Notes (coste fijo anual), Almacén físico (coste fijo anual), Proyectos de innovación (3000 horas de soporte), Proceso y gestión de la transición (coste fijo único). [ANEXO V.xls, hoja Lote 2]
  - Lote 3: Virtualización (UDS Virtual Cable Enterprise: 1 instancia), Gestión de datos de prueba (ICARIA TDM: 1 instancia), Motor de procesos (Camunda: 1 suscripción), Bolsa de horas de soporte (1800), ElasticSearch Enterprise (23 nodos), DB2 Advanced (22 CPU), DB2 Advanced + IIDDR (2 instancias), MongoDB (1200 horas de soporte), RAM (1 suscripción), Microsoft SQLServer Standard (40 CPU). [ANEXO V.xls, hoja Lote 3]

## 11. Condiciones de ejecución, penalizaciones y continuidad

- El incumplimiento de los hitos críticos de la fase de transición (infraestructura/software disponible, herramientas de monitorización y modelo ANS implantados, validación del servicio mediante pruebas y paralelos, aceptación del nuevo servicio) constituye incumplimiento contractual. [ANEXO D.pdf, pág. 30-31, 39]
- El incumplimiento de la condición especial de ejecución sobre conciliación laboral da lugar a penalidad. [CP001522024 ANEXOS.doc, Anexo VI]
- El incumplimiento de los acuerdos de nivel de servicio (ANS) da lugar a penalizaciones según el modelo de penalizaciones del pliego. [ANEXO C.pdf, pág. 29-30]

## 12. Discrepancias y pendientes de aclaración

- NO SE HAN IDENTIFICADO DISCREPANCIAS en la documentación revisada respecto a los requisitos de perfiles y equipo, estructura mínima, titulaciones, experiencia, dedicación, cobertura, sustituciones, adscripción, acreditación, criterios puntuables y condiciones de ejecución.
- NO CONSTA EN LA DOCUMENTACION REVISADA ningún requisito de experiencia mínima individual, titulación o jornada mínima por perfil para los técnicos de los lotes 1 y 2.
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de CV, vida laboral, ni relación nominal de equipo en la oferta inicial.
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de presencialidad, ubicación física concreta, ni jornada mínima o máxima individual por perfil.
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de idioma extranjero distinto de castellano o catalán.
- NO CONSTA EN LA DOCUMENTACION REVISADA exigencia de número mínimo de personas por perfil, salvo la obligación de dimensionar el equipo para cubrir el servicio y las guardias 24x7x365 por área de conocimiento.

---

**Fin del registro de requisitos de perfiles y equipo para CP00152/2024 (ASEPEYO).**